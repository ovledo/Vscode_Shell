from openpyxl import load_workbook

wb_input = load_workbook('mega_result.xlsx')
ws_input = wb_input.active

Contrast = []
Excel_count = 6
for i in range(1, 6):
    Contrast_Column = 1 + 8 * i
    Contrast.append(Contrast_Column)

# 获取第一个表格的第一列和第二列数据，并将其添加到第二个表格相同位置
for division in Contrast:
    print('This is' + str(division))
    for row_idx in range(3, ws_input.max_row + 1):
        value_1 = ws_input.cell(row=row_idx, column=9).value
        value_2 = ws_input.cell(row=row_idx, column=division).value
        print('This is Value1' + '    ' + str(value_1))
        print('This is Value2' + '    ' + str(value_2))
        result = value_2 / value_1
        print(result)
        ws_input.cell(row=row_idx, column=division + 1).value = result

wb_input.save('mega_result.xlsx')
