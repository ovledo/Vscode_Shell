import os
import pandas as pd
from openpyxl import load_workbook

i=3
Dirpath = os.getcwd()
column_list = []
df = pd.read_excel('result_Cycle1.xlsx')

for read in df.columns[2:]:
    column_list.append(read)


def process_excel(filepath, column_list):
    try:
        # 读取 Excel 文件内容
        df = pd.read_excel(filepath)

        # 存储处理结果的字典
        column_dataframes = {}

        # 迭代每个列
        for column in column_list:

            # 筛选特定列
            filtered_column = df.filter(like=column)
            # 检查筛选结果是否为空
            if not filtered_column.empty:
                # 将筛选后的列添加到字典中
                column_dataframes[column] = filtered_column

        # 返回处理结果的字典
        return column_dataframes
    except Exception as e:
        print(f"处理文件 '{filepath}' 失败: {e}")
        return None


# 存储所有处理结果的字典
all_results = {}

# 遍历当前文件夹
for filename in os.listdir(Dirpath):
    # 构建文件的完整路径
    filepath = os.path.join(Dirpath, filename)
    # 检查文件是否为 Excel 文件
    if filename.startswith("result_Cycle") and filename.endswith(".xlsx"):
        # 输出 Excel 文件的路径
        print(f"处理文件: {filename}")
        # 调用处理函数并将结果添加到字典中
        result = process_excel(filepath, column_list)
        if result is not None:
            for column, dataframe in result.items():
                # 将处理结果存储到 all_results 字典中
                if column not in all_results:
                    all_results[column] = []
                all_results[column].append(dataframe)

# 合并每个列的 DataFrame
merged_results = {}
for column, dataframes in all_results.items():
    merged_results[column] = pd.concat(dataframes, axis=1)

# 计算每行的平均值并添加到 DataFrame 的最后一列
for column, merged_df in merged_results.items():
    merged_df['Row_Average'] = merged_df.mean(axis=1)

# 输出合并后的结果
for column, merged_df in merged_results.items():
    print(f"\n合并后的结果 - Column {column}:")
    print(merged_df)

    # 打开现有的 Excel 文件
    wb = load_workbook('modified_result_Cycle1.xlsx')

    # 获取当前工作表
    ws = wb.active

    # 将 DataFrame 写入到指定位置
    for r_idx, row in enumerate(merged_df.values, start=3):
        for c_idx, value in enumerate(row, start=i):
            ws.cell(row=r_idx, column=c_idx, value=value)

    # 保存 Excel 文件
    wb.save('modified_result_Cycle1.xlsx')

    # 更新起始列的位置
    i += 8