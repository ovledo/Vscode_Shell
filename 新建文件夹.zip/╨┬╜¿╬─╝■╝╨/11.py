import glob
import os
from openpyxl import load_workbook
import pandas as pd
from openpyxl.utils import get_column_letter
from xlsxwriter import Workbook
from xlwt import Alignment


def count_result_files(directory):
    pattern = os.path.join(directory, 'result*.xlsx')
    result_files = glob.glob(pattern)
    count = len(result_files)
    return count

def modify_excel(filename, excel_count):
    workbook = load_workbook(filename=filename)
    sheet = workbook.active
    new_workbook = Workbook()
    new_sheet = new_workbook.active
    first_row_values = [cell.value for cell in sheet[1]]
    for col, value in enumerate(first_row_values, start=1):
        if col == 1:
            new_sheet.cell(row=1, column=col, value=value)
        elif col == 2:
            new_sheet.cell(row=1, column=col, value=value)
        else:
            new_sheet.cell(row=1, column=3 + (col - 3) * (excel_count + 2), value=value)
    new_workbook.save(filename="modified_" + filename)

def merge_excel_and_save(input_filename, output_filename, excel_count):
    wb = load_workbook(input_filename)
    ws = wb.active
    max_column = ws.max_column
    start_col = None
    for col in range(1, max_column + 1):
        cell = ws.cell(row=1, column=col)
        if start_col is None and cell.value is not None:
            start_col = col
        elif start_col is not None and cell.value is not None:
            end_col = col - 1
            merge_range = f"{get_column_letter(start_col)}1:{get_column_letter(end_col)}1"
            ws.merge_cells(merge_range)
            start_col = col
    last_column_letter = get_column_letter(max_column)
    merge_range = f"{last_column_letter}1:{get_column_letter(max_column + excel_count -1 )}1"
    ws.merge_cells(merge_range)
    for col in range(1, max_column + 1):
        cell = ws.cell(row=1, column=col)
        cell.alignment = Alignment(horizontal='center')
    wb.save(output_filename)

def copy_columns(input_filename, output_filename):
    wb_input = load_workbook(input_filename)
    ws_input = wb_input.active
    wb_output = load_workbook(output_filename)
    ws_output = wb_output.active
    for row_idx in range(1, ws_input.max_row + 1):
        value_1 = ws_input.cell(row=row_idx, column=1).value
        value_2 = ws_input.cell(row=row_idx, column=2).value
        ws_output.cell(row=row_idx, column=1).value = value_1
        ws_output.cell(row=row_idx, column=2).value = value_2
    wb_output.save(output_filename)

def move_column(input_filename):
    wb = load_workbook(input_filename)
    ws = wb.active
    column_data_1 = [cell.value for cell in ws['A']]
    column_data_2 = [cell.value for cell in ws['B']]
    new_column_data_1 = [None] * len(column_data_1)
    new_column_data_2 = [None] * len(column_data_2)
    for idx, value in enumerate(column_data_1, start=1):
        new_column_data_1[idx - 1] = value
        ws.cell(row=idx, column=1).value = None
    for idx, value in enumerate(column_data_2, start=1):
        new_column_data_2[idx - 1] = value
        ws.cell(row=idx, column=2).value = None
    for idx, (value_1, value_2) in enumerate(zip(new_column_data_1, new_column_data_2), start=2):
        ws.cell(row=idx, column=1, value=value_1)
        ws.cell(row=idx, column=2, value=value_2)
    wb.save(input_filename)

def process_excel(filepath, column_list):
    try:
        df = pd.read_excel(filepath)
        column_dataframes = {}
        for column in column_list:
            filtered_column = df.filter(like=column)
            if not filtered_column.empty:
                column_dataframes[column] = filtered_column
        return column_dataframes
    except Exception as e:
        print(f"处理文件 '{filepath}' 失败: {e}")
        return None

def main():
    directory = os.getcwd()
    excel_file = 'modified_result_Cycle1.xlsx'
    excel_count = count_result_files(directory)
    modify_excel("result_Cycle1.xlsx", excel_count)
    merge_excel_and_save('modified_result_Cycle1.xlsx', 'modified_result_Cycle1.xlsx', excel_count)
    copy_columns('result_Cycle1.xlsx', 'modified_result_Cycle1.xlsx')
    move_column('modified_result_Cycle1.xlsx')
    column_list = []
    df = pd.read_excel('result_Cycle1.xlsx')
    for read in df.columns[2:]:
        column_list.append(read)
    all_results = {}
    for filename in os.listdir(directory):
        filepath = os.path.join(directory, filename)
        if filename.startswith("result_Cycle") and filename.endswith(".xlsx"):
            print(f"处理文件: {filename}")
            result = process_excel(filepath, column_list)
            if result is not None:
                for column, dataframe in result.items():
                    if column not in all_results:
                        all_results[column] = []
                    all_results[column].append(dataframe)
    merged_results = {}
    for column, dataframes in all_results.items():
        merged_results[column] = pd.concat(dataframes, axis=1)
    for column, merged_df in merged_results.items():
        wb = load_workbook('modified_result_Cycle1.xlsx')
        ws = wb.active
        for r_idx, row in enumerate(merged_df.values, start=3):
            for c_idx, value in enumerate(row, start=3):
                ws.cell(row=r_idx, column=c_idx, value=value)
        wb.save('modified_result_Cycle1.xlsx')

if __name__ == "__main__":
    main()
