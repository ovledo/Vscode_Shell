from openpyxl import load_workbook

# 加载Excel文件
wb = load_workbook(filename='modified_result_Cycle1.xlsx')
sheet = wb.active
# 获取合并单元格范围
merged_ranges = sheet.merged_cells.ranges

element = []
Element_sort = []
seen = set()
for col in range(1, sheet.max_column + 1):
    cell = sheet.cell(row=1, column=col)
    element.append(cell.value)
Element = [x for x in element if x is not None]
[Element_sort.append(x) for x in Element if x not in seen and not seen.add(x)]
print(Element_sort)

# 搜索包含特定值的合并单元格
add_cell = []
for target_value in Element_sort:
    for merged_range in merged_ranges:
        min_row, min_col, max_row, max_col = merged_range.min_row, merged_range.min_col, merged_range.max_row, merged_range.max_col
        for row in range(min_row, max_row + 1):
            for col in range(min_col, max_col + 1):
                if sheet.cell(row=row, column=col).value == target_value:
                    print("包含"+target_value+"范围:", merged_range)
                    add_cell.append(max_col)
                    break

add_cell = sorted(add_cell)
print(add_cell)