import glob
import os
from openpyxl import Workbook
from openpyxl import load_workbook
from openpyxl.styles import Alignment
from openpyxl.utils import get_column_letter
import pandas as pd


def count_result_files(directory):
    # 设置匹配模式
    pattern = os.path.join(directory, 'result*.xlsx')

    # 使用 glob 模块匹配文件名
    result_files = glob.glob(pattern)

    # 获取匹配到的文件数量
    count = len(result_files)

    return count

Excel_count = count_result_files(os.getcwd())

def merge_excel_and_save(input_filename, output_filename):

    workbook = load_workbook(filename='result_Cycle1.xlsx')
    sheet = workbook.active
    new_workbook = Workbook()
    new_sheet = new_workbook.active
    first_row_values = [cell.value for cell in sheet[1]]

    # 在新的工作表中写入第一行数据，每两个数据之间插入 3 个空格
    for col, value in enumerate(first_row_values, start=1):
        if col == 1:  # A1 单元格
            new_sheet.cell(row=1, column=col, value=value)
        elif col == 2:  # B1 单元格
            new_sheet.cell(row=1, column=col, value=value)
        else:  # 从 C1 单元格开始，每两个单元格之间插入 3 个空格
            new_sheet.cell(row=1, column=3 + (col - 3) * (Excel_count + 2), value=value)

    new_workbook.save(filename='mega_result.xlsx')

    # 加载Excel文件
    wb = load_workbook(input_filename)
    ws = wb.active

    # 获取表格的最大行数和最大列数
    max_row = ws.max_row
    max_column = ws.max_column

    # 初始化当前合并范围的起始列
    start_col = None

    # 遍历第一行的每个单元格
    for col in range(1, max_column + 1):
        cell = ws.cell(row=1, column=col)
        # 如果当前单元格为空，检查是否需要开始合并
        if start_col is None and cell.value is not None:
            start_col = col
        elif start_col is not None and cell.value is not None:
            # 如果前面有非空单元格，将起始列到当前列的所有单元格合并
            end_col = col - 1
            merge_range = f"{get_column_letter(start_col)}1:{get_column_letter(end_col)}1"
            ws.merge_cells(merge_range)
            start_col = col

    last_column_letter = get_column_letter(max_column)
    merge_range = f"{last_column_letter}1:{get_column_letter(max_column + Excel_count -1 )}1"

    ws.merge_cells(merge_range)

    # 设置合并后单元格的对齐方式为居中
    for col in range(1, max_column + 1):
        cell = ws.cell(row=1, column=col)
        cell.alignment = Alignment(horizontal='center')

    # 保存修改后的Excel文件
    wb.save(output_filename)

# 调用函数并指定输入和输出文件名
merge_excel_and_save('mega_result.xlsx', 'mega_result.xlsx')

def copy_columns(input_filename, output_filename):
    # 加载第一个表格
    wb_input = load_workbook(input_filename)
    ws_input = wb_input.active

    # 加载第二个表格
    wb_output = load_workbook(output_filename)
    ws_output = wb_output.active

    # 获取第一个表格的第一列和第二列数据，并将其添加到第二个表格相同位置
    for row_idx in range(1, ws_input.max_row + 1):
        value_1 = ws_input.cell(row=row_idx, column=1).value
        value_2 = ws_input.cell(row=row_idx, column=2).value
        ws_output.cell(row=row_idx, column=1).value = value_1
        ws_output.cell(row=row_idx, column=2).value = value_2

    # 保存第二个表格
    wb_output.save(output_filename)
# 调用函数并指定输入和输出文件名
copy_columns('result_Cycle1.xlsx', 'mega_result.xlsx')

def move_column(input_filename):
    # 加载 Excel 文件
    wb = load_workbook(input_filename)
    ws = wb.active

    # 读取第一列和第二列数据
    column_data_1 = [cell.value for cell in ws['A']]
    column_data_2 = [cell.value for cell in ws['B']]

    # 保存要移动的数据
    new_column_data_1 = [None] * len(column_data_1)
    new_column_data_2 = [None] * len(column_data_2)

    # 处理第一列数据
    for idx, value in enumerate(column_data_1, start=1):
        new_column_data_1[idx - 1] = value  # 将数据存储到新的列表中
        ws.cell(row=idx, column=1).value = None  # 清空原始位置的数据

    # 处理第二列数据
    for idx, value in enumerate(column_data_2, start=1):
        new_column_data_2[idx - 1] = value  # 将数据存储到新的列表中
        ws.cell(row=idx, column=2).value = None  # 清空原始位置的数据

    # 从第二行开始写入新数据
    for idx, (value_1, value_2) in enumerate(zip(new_column_data_1, new_column_data_2), start=2):
        ws.cell(row=idx, column=1, value=value_1)
        ws.cell(row=idx, column=2, value=value_2)

    # 保存修改后的 Excel 文件
    wb.save(input_filename)

# 调用函数并指定输入文件名
move_column('mega_result.xlsx')


# 指定目录和文件名
directory = os.getcwd()
excel_file = 'mega_result.xlsx'

# 加载现有的Excel文件
wb = load_workbook(os.path.join(directory, excel_file))
ws = wb.active

# 初始化列表
file_list = []

# 遍历目录下所有文件
for file in os.listdir(directory):
    if file.startswith('result_') and file.endswith('.xlsx'):
        file_name = file.replace('result_', '').replace('.xlsx', '')
        file_list.append(file_name)

# 在列表最后添加'Average'和'Contrast'
file_list.extend(['Average', 'Contrast'])

# 获取表格的最大列数
max_column = ws.max_column

# 计算列表需要重复写入的次数
repeat_times = (max_column - 2) // len(file_list)

# 计算剩余的列数
remaining_columns = (max_column - 2) % len(file_list)

# 从第二行的第三列开始写入列表内容
start_column = 3
for i in range(repeat_times):
    for col_index, value in enumerate(file_list, start=start_column):
        ws.cell(row=2, column=col_index, value=value)
    start_column += len(file_list)

# 如果还有剩余列，继续写入剩余的列表内容
if remaining_columns > 0:
    for col_index, value in enumerate(file_list[:remaining_columns], start=start_column):
        ws.cell(row=2, column=col_index, value=value)

# 保存Excel文件
wb.save(os.path.join(directory, excel_file))

i=3
column_list = []
df = pd.read_excel('result_Cycle1.xlsx')

for read in df.columns[2:]:
    column_list.append(read)


def process_excel(filepath, column_list):
    try:
        # 读取 Excel 文件内容
        df = pd.read_excel(filepath)

        # 存储处理结果的字典
        column_dataframes = {}

        # 迭代每个列
        for column in column_list:

            # 筛选特定列
            filtered_column = df.filter(like=column)
            # 检查筛选结果是否为空
            if not filtered_column.empty:
                # 将筛选后的列添加到字典中
                column_dataframes[column] = filtered_column

        # 返回处理结果的字典
        return column_dataframes
    except Exception as e:
        print(f"处理文件 '{filepath}' 失败: {e}")
        return None


# 存储所有处理结果的字典
all_results = {}

# 遍历当前文件夹
for filename in os.listdir(directory):
    # 构建文件的完整路径
    filepath = os.path.join(directory, filename)
    # 检查文件是否为 Excel 文件
    if filename.startswith("result_Cycle") and filename.endswith(".xlsx"):
        # 输出 Excel 文件的路径
        print(f"处理文件: {filename}")
        # 调用处理函数并将结果添加到字典中
        result = process_excel(filepath, column_list)
        if result is not None:
            for column, dataframe in result.items():
                # 将处理结果存储到 all_results 字典中
                if column not in all_results:
                    all_results[column] = []
                all_results[column].append(dataframe)

# 合并每个列的 DataFrame
merged_results = {}
for column, dataframes in all_results.items():
    merged_results[column] = pd.concat(dataframes, axis=1)

# 计算每行的平均值并添加到 DataFrame 的最后一列
for column, merged_df in merged_results.items():
    merged_df['Row_Average'] = merged_df.mean(axis=1)

# 输出合并后的结果
for column, merged_df in merged_results.items():
    # 打开现有的 Excel 文件
    wb = load_workbook('mega_result.xlsx')

    # 获取当前工作表
    ws = wb.active

    # 将 DataFrame 写入到指定位置
    for r_idx, row in enumerate(merged_df.values, start=3):
        for c_idx, value in enumerate(row, start=i):
            ws.cell(row=r_idx, column=c_idx, value=value)

    # 保存 Excel 文件
    wb.save('mega_result.xlsx')

    # 更新起始列的位置
    i += Excel_count + 2




