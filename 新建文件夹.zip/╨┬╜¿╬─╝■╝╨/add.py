import os
import pandas as pd
from openpyxl import load_workbook

# 指定目录
directory = os.getcwd()

# 初始化一个空的二维列表来存储匹配的数据
matched_data = []

# 遍历当前目录下所有以'result_Cycle'开头的表格
for file in os.listdir(directory):
    if file.startswith('result_Cycle') and file.endswith('.xlsx'):
        # 读取当前表格的表头，从第三列开始
        current_table_data = pd.read_excel(os.path.join(directory, file), header=None)
        current_header = current_table_data.iloc[:, 2:].iloc[0].tolist()
        # 寻找包含 'RW_4K_50%' 的列名
        matched_column = [col for col in current_header if 'RW_4k_50%' in col]
        # 如果找到匹配的列，则将该列数据存入二维列表
        if matched_column:
            matched_column_index = current_header.index(matched_column[0]) + 2  # 获取匹配列的索引，考虑到从第三列开始
            current_table_column_data = current_table_data.iloc[:, matched_column_index].tolist()
            matched_data.append(current_table_column_data)

# 读取现有的Excel文件
excel_file = 'modified_result_Cycle1.xlsx'
wb = load_workbook(os.path.join(directory, excel_file))
ws = wb.active

# 将匹配的数据写入Excel文件的指定位置，不包括第一列
for row_index, row in enumerate(matched_data, start=1):
    for col_index, value in enumerate(row, start=1):
        if row_index == 3 and col_index == 3:  # 将数据写入到C3单元格
            ws.cell(row=row_index, column=col_index, value=value)

# 保存Excel文件
wb.save(os.path.join(directory, excel_file))
print(f"数据已成功写入文件 '{excel_file}' 的C3单元格中。")
